
const { loadSettings, saveSettings } = require('../lib/settings')

module.exports = {
    name: "mode",
    alias: ["setmode"],
    category: "Owner",
    react: "🌐",
    start: async (bot, msg, args) => {

        if (!args[0]) return msg.reply("Use: .mode public / private")

        let md = args[0].toLowerCase()
        if (md !== "public" && md !== "private")
            return msg.reply("🛑 Invalid mode!")

        let s = loadSettings()
        s.mode = md
        saveSettings(s)

        msg.reply(`✅ Bot mode set to: *${md}*`)
    }
}
