
const { loadSettings, saveSettings } = require('../lib/settings')

module.exports = {
    name: "autoreply",
    alias: ["ar"],
    category: "Owner",
    react: "💬",
    start: async (bot, msg, args) => {

        let s = loadSettings()

        if (args[0] === "on") s.autoreply = true
        else if (args[0] === "off") s.autoreply = false
        else return msg.reply("Use: .autoreply on / off")

        saveSettings(s)

        msg.reply(`💬 AutoReply: *${s.autoreply ? "ON" : "OFF"}*`)
    }
}
