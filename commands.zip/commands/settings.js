
const { loadSettings } = require('../lib/settings')

module.exports = {
    name: "settings",
    alias: ["config"],
    desc: "Show bot settings",
    react: "⚙️",
    category: "Owner",
    start: async (bot, msg) => {

        let s = loadSettings()

        let text = `⚙ *BOT SETTINGS*\n
👑 Owner : ${s.owner}
🔧 Prefix : ${s.prefix}
🤖 Bot Name : ${s.botName}
💬 Auto Reply : ${s.autoreply}
🌐 Mode : ${s.mode}
`

        await bot.sendMessage(msg.from, { text }, { quoted: msg })
    }
}
