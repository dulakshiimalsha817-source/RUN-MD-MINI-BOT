
const { loadSettings, saveSettings } = require('../lib/settings')

module.exports = {
    name: "setprefix",
    alias: ["prefix"],
    category: "Owner",
    react: "🔧",
    start: async (bot, msg, args) => {

        if (!args[0]) return msg.reply("🥷ꜱᴀɴɴᴜ ᴍᴅ ᴍɪɴɪ ʙᴏᴛ ꜰʀᴇᴇ ᴜᴘᴅᴀᴛᴇ ɴᴏᴡ🍂")

        let s = loadSettings()
        s.prefix = args[0]
        saveSettings(s)

        msg.reply(`✅ Prefix changed to: *${args[0]}*`)
    }
}
